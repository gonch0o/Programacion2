/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio14;

/**
 *
 * @author gonzalo
 */
public class EditorVideo {
    public void exportar(String formato, Proyecto proyecto) {
        Render render = new Render(formato);
        System.out.println("Exportando proyecto '" + proyecto.getNombre() +
                "' de " + proyecto.getDuracionMin() +
                " min en formato " + render.getFormato());
    }
}
