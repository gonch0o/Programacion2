/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio14;

/**
 *
 * @author gonzalo
 */
public class Render {
    private String formato;

    public Render(String formato) {
        this.formato = formato;
    }

    public String getFormato() {
        return formato;
    }
}
