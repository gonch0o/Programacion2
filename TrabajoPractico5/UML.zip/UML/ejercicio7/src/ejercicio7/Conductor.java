/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio7;

/**
 *
 * @author gonzalo
 */
public class Conductor {
    private final String nombre;
    private final String licencia;
    private Vehiculo vehiculo;

    public Conductor(String nombre, String licencia) {
        this.nombre = nombre;
        this.licencia = licencia;
    }

    public String getNombre() { return nombre; }
    public String getLicencia() { return licencia; }
    public Vehiculo getVehiculo() { return vehiculo; }

    public void setVehiculo(Vehiculo nuevo) {
        if (this.vehiculo == nuevo) return;
        if (this.vehiculo != null) {
            Vehiculo viejo = this.vehiculo;
            this.vehiculo = null;
            if (viejo.getConductor() == this) viejo.setConductor(null);
        }
        this.vehiculo = nuevo;
        if (nuevo != null && nuevo.getConductor() != this) {
            nuevo.setConductor(this);
        }
    }
    
}
