/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio7;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Motor motor = new Motor("Nafta", "MTR-445566");
        Vehiculo vehiculo = new Vehiculo("AC987GH", "Honda Civic");
        Conductor conductor = new Conductor("Gonzalo Ojeda", "L1234567");

        vehiculo.setMotor(motor);
        vehiculo.setConductor(conductor);

        // Mostrar datos sin usar toString
        System.out.println("Vehículo: " + vehiculo.getPatente() + " - " + vehiculo.getModelo());
        System.out.println("Motor: " + motor.getTipo() + " - " + motor.getNumeroSerie());
        System.out.println("Conductor: " + conductor.getNombre() + " - Licencia " + conductor.getLicencia());
    
    }
    
}
