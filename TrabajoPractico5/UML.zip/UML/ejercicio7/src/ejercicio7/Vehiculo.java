/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio7;

/**
 *
 * @author gonzalo
 */
public class Vehiculo {
    private final String patente;
    private final String modelo;
    private Motor motor;          
    private Conductor conductor;  

    public Vehiculo(String patente, String modelo) {
        this.patente = patente;
        this.modelo = modelo;
    }

    public String getPatente() { return patente; }
    public String getModelo() { return modelo; }
    public Motor getMotor() { return motor; }
    public Conductor getConductor() { return conductor; }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    public void setConductor(Conductor nuevo) {
        if (this.conductor == nuevo) return;
        if (this.conductor != null) {
            Conductor viejo = this.conductor;
            this.conductor = null;
            if (viejo.getVehiculo() == this) viejo.setVehiculo(null);
        }
        this.conductor = nuevo;
        if (nuevo != null && nuevo.getVehiculo() != this) {
            nuevo.setVehiculo(this);
        }
    }
    
}
