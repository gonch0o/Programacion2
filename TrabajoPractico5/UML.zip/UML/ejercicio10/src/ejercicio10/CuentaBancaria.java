/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio10;

/**
 *
 * @author gonzalo
 */
public class CuentaBancaria {
    private final String cbu;
    private double saldo;
    private final ClaveSeguridad clave; 
    private Titular titular;            

    public CuentaBancaria(String cbu, double saldo, ClaveSeguridad clave) {
        this.cbu = cbu;
        this.saldo = saldo;
        this.clave = clave;
    }

    public String getCbu() { 
        return cbu; 
    }
    public double getSaldo() { 
        return saldo; 
    }
    public ClaveSeguridad getClave() { 
        return clave; 
    }
    public Titular getTitular() { 
        return titular; 
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setTitular(Titular nuevo) {
        if (this.titular == nuevo) return;
        
        if (this.titular != null) {
            Titular viejo = this.titular;
            this.titular = null;
            if (viejo.getCuenta() == this) viejo.setCuenta(null);
        }
        
        this.titular = nuevo;
        if (nuevo != null && nuevo.getCuenta() != this) {
            nuevo.setCuenta(this);
        }
    }
}
