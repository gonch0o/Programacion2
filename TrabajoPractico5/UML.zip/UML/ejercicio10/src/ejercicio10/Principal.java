/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio10;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ClaveSeguridad clave = new ClaveSeguridad("ABC123", "2025-09-30");
        CuentaBancaria cuenta = new CuentaBancaria("0001234567890009876543", 250000.50, clave);
        Titular titular = new Titular("Gonzalo Ojeda", "38565001");

        cuenta.setTitular(titular);

        System.out.println("Cuenta: " + cuenta.getCbu() + " Saldo: $" + cuenta.getSaldo());
        System.out.println("Clave: " + cuenta.getClave().getCodigo() + " - Última modif: " + cuenta.getClave().getUltimaModificacion());
        System.out.println("Titular: " + titular.getNombre() + " DNI: " + titular.getDni());
    }
    
}
