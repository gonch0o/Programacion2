/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio10;

/**
 *
 * @author gonzalo
 */
public class Titular {
    private final String nombre;
    private final String dni;
    private CuentaBancaria cuenta; 

    public Titular(String nombre, String dni) {
        this.nombre = nombre;
        this.dni = dni;
    }

    public String getNombre() { 
        return nombre; 
    }
    public String getDni() { 
        return dni; 
    }
    public CuentaBancaria getCuenta() { 
        return cuenta; 
    }

    public void setCuenta(CuentaBancaria nueva) {
        if (this.cuenta == nueva) return;
        
        if (this.cuenta != null) {
            CuentaBancaria vieja = this.cuenta;
            this.cuenta = null;
            if (vieja.getTitular() == this) vieja.setTitular(null);
        }
        
        this.cuenta = nueva;
        if (nueva != null && nueva.getTitular() != this) {
            nueva.setTitular(this);
        }
    }
}
