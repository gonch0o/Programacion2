/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Banco banco = new Banco("BBVA", "30-12345678-9");
        TarjetaDeCredito tarjeta = new TarjetaDeCredito("1234-5678-9123-4567", "05/26");
        Cliente cliente = new Cliente("Gonzalo Ojeda", "38680225");

        tarjeta.setBanco(banco);
        tarjeta.setCliente(cliente);

        System.out.println("Tarjeta: " + tarjeta.getNumero() + " vence " + tarjeta.getFechaVencimiento());
        System.out.println("Cliente: " + cliente.getNombre() + " (" + cliente.getDni() + ")");
        System.out.println("Banco: " + banco.getNombre() + " CUIT " + banco.getCuit());

    }
    
}
