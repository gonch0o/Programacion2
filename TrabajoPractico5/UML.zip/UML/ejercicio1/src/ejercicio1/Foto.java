/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author gonzalo
 */
public class Foto {
    private final String imagen;
    private final String formato;

    public Foto(String imagen, String formato) {
        this.imagen = imagen;
        this.formato = formato;
    }

    public String getImagen() { 
        return imagen; }
    public String getFormato() { 
        return formato; }

    @Override
    public String toString() {
        return imagen + "." + formato;
    }
    
    
    
}
