/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author gonzalo
 */
public class Pasaporte {
    private final String numero;
    private final String fechaEmision;
    private final Foto foto; 
    private Titular titular;

    public Pasaporte(String numero, String fechaEmision, Foto foto) {
        this.numero = numero;
        this.fechaEmision = fechaEmision;
        this.foto = foto;
    }

    public String getNumero() {return numero; }
    public String getFechaEmision() { return fechaEmision; }
    public Foto getFoto() { return foto; }

    public Titular getTitular() { return titular; }
    public void setTitular(Titular nuevo) {
        if (this.titular == nuevo) return;

        if (this.titular != null) {
            Titular viejo = this.titular;
            this.titular = null;
            if (viejo.getPasaporte() == this) viejo.setPasaporte(null);
        }

        this.titular = nuevo;
        if (nuevo != null && nuevo.getPasaporte() != this) {
            nuevo.setPasaporte(this);
    }
        
    }

    @Override
    public String toString() {
        return "Pasaporte{" + "numero=" + numero + ", fechaEmision=" + fechaEmision + ", foto=" + foto + ", titular=" + titular + '}';
    }
}
          

