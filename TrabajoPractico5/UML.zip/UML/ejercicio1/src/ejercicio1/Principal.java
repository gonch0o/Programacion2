/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Foto foto = new Foto("foto_perfil", "jpg");
        Pasaporte pasaporte = new Pasaporte("AR12345", "2025-09-15", foto);
        Titular titular = new Titular("Gonzalo Ojeda", "38680225");

        pasaporte.setTitular(titular);

        System.out.println(pasaporte);
        System.out.println(titular);
    }
    
}
