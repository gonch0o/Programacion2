/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author gonzalo
 */
public class Titular {
    private final String nombre;
    private final String dni;
    private Pasaporte pasaporte; // vínculo bidireccional

    public Titular(String nombre, String dni) {
        this.nombre = nombre;
        this.dni = dni;
    }

    public String getNombre() { return nombre; }
    public String getDni() { return dni; }

    public Pasaporte getPasaporte() { return pasaporte; }
    public void setPasaporte(Pasaporte nuevo) {
        if (this.pasaporte == nuevo) return;

        // desvincular el viejo
        if (this.pasaporte != null) {
            Pasaporte viejo = this.pasaporte;
            this.pasaporte = null;
            if (viejo.getTitular() == this) viejo.setTitular(null);
        }

        // vincular el nuevo
        this.pasaporte = nuevo;
        if (nuevo != null && nuevo.getTitular() != this) {
            nuevo.setTitular(this);
        }
    }

    @Override
    public String toString() {
        return "Titular{nombre=" + nombre + ", dni=" + dni + "}";
            
        }
    }
