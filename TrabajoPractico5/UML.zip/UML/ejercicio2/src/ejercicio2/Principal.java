/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Celular cel = new Celular("355123456789012", "Samsung", "A52");
       cel.setBateria(new Bateria("EB-BA525", 4500));

       Usuario usu = new Usuario("Gonzalo Ojeda", "38680225");
       cel.setUsuario(usu);

       System.out.println(cel);
       System.out.println(usu);
       System.out.println("Usuario->Celular == cel ? " + (usu.getCelular() == cel));
    }
    
}
