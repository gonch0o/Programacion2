/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio6;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Gonzalo Ojeda", "1169603360");
        Mesa mesa = new Mesa(12, 4);
        Reserva reserva = new Reserva("2025-10-10", "21:30");

        reserva.setCliente(cliente);
        reserva.setMesa(mesa);
        
        System.out.println("Reserva: " + reserva.getFecha() + " " + reserva.getHora());
        System.out.println("Cliente: " + cliente.getNombre() + " - " + cliente.getTelefono());
        System.out.println("Mesa: " + mesa.getNumero() + " - Capacidad " + mesa.getCapacidad());
    
    }
    
}
