/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio8;

/**
 *
 * @author gonzalo
 */
public class Documento {
    private final String titulo;
    private final String contenido;
    private final FirmaDigital firma; // composición

    public Documento(String titulo, String contenido, FirmaDigital firma) {
        this.titulo = titulo;
        this.contenido = contenido;
        this.firma = firma;
    }

    public String getTitulo() { 
        return titulo; 
    }
    public String getContenido() { 
        return contenido; 
    }
    public FirmaDigital getFirma() { 
        return firma; 
    }
}
