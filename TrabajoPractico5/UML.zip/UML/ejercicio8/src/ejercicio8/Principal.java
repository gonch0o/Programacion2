/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Usuario usuario = new Usuario("Gonzalo Ojeda", "gonzalo.ojeda@mail.com");
        FirmaDigital firma = new FirmaDigital("HASH123456789", "2025-09-30");
        firma.setUsuario(usuario);
        Documento documento = new Documento("Contrato de Trabajo", "Contenido del contrato...", firma);

        // Mostrar datos
        System.out.println("Documento: " + documento.getTitulo());
        System.out.println("Contenido: " + documento.getContenido());
        System.out.println("Firma: " + documento.getFirma().getCodigoHash() + " - Fecha: " + documento.getFirma().getFecha());
        System.out.println("Firmado por: " + documento.getFirma().getUsuario().getNombre() +
                           " - Email: " + documento.getFirma().getUsuario().getEmail());
    }
    
}
