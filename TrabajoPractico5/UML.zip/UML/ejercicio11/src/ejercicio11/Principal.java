/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio11;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Artista artista = new Artista("NTVG", "Rock");
        Cancion cancion = new Cancion("Memorias del olvido", artista);

        Reproductor reproductor = new Reproductor();
        reproductor.reproducir(cancion);
    }
    
}
