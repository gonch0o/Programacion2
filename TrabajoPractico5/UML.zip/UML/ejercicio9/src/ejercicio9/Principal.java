/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio9;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Paciente paciente = new Paciente("Gonzalo Ojeda", "Premedic");
        Profesional profesional = new Profesional("Dr. Juan Perez", "Cardiología");
        CitaMedica cita = new CitaMedica("2025-10-01", "8:00");

        cita.setPaciente(paciente);
        cita.setProfesional(profesional);

        System.out.println("Cita médica:");
        System.out.println("Fecha: " + cita.getFecha() + " Hora: " + cita.getHora());
        System.out.println("Paciente: " + cita.getPaciente().getNombre() + " (Obra Social: " + cita.getPaciente().getObraSocial() + ")");
        System.out.println("Profesional: " + cita.getProfesional().getNombre() + " - " + cita.getProfesional().getEspecialidad());
    }
    
}
