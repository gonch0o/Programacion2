/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package claselibro;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Libro libro1 = new Libro("El Principito", "Antoine de Saint-Exupéry", 1943);

       
        System.out.println("informacion inicial:");
        libro1.mostrarInfo();

        System.out.println("\nIntentando asignar año invalido (-100)...");
        libro1.setAnioPublicacion(-100);

        System.out.println("\nAsignando año valido (2000)...");
        libro1.setAnioPublicacion(2000);

        System.out.println("\nInformacion final:");
        libro1.mostrarInfo();
    }
    
}
