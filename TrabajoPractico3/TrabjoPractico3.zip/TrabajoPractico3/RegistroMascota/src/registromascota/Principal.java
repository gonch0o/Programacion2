/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registromascota;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mascota mc = new Mascota("Milo", "Gato", 2);

        // Información inicial
        System.out.println("📌 Información inicial:");
        mc.mostrarInfo();

        // Cumpleaños (incrementa edad)
        mc.cumplirAnios();

        // Información actualizada
        System.out.println("\n📌 Información actualizada:");
        mc.mostrarInfo();
    }
}
