/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simulacion;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NaveEspacial nave1 = new NaveEspacial("Exploradora", 50);

        nave1.mostrarEstado();

        nave1.avanzar(15);
        
        nave1.recargarCombustible(40);
        
        nave1.despegar();

        nave1.avanzar(10);
        
        nave1.mostrarEstado();
    }
    
}
