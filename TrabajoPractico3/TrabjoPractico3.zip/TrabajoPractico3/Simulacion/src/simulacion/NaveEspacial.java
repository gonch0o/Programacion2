/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacion;

/**
 *
 * @author gonzalo
 */
public class NaveEspacial {
     private String nombre;
    private int combustible;
    private final int MAX_COMBUSTIBLE = 100; // límite máximo

    // Constructor
    public NaveEspacial(String nombre, int combustible) {
        this.nombre = nombre;
        if (combustible <= MAX_COMBUSTIBLE) {
            this.combustible = combustible;
        } else {
            this.combustible = MAX_COMBUSTIBLE;
        }
    }

    // Método para despegar
    public void despegar() {
        if (combustible >= 10) {
            combustible -= 10;
            System.out.println("La nave " + nombre + " ha despegado. Combustible restante: " + combustible);
        } else {
            System.out.println("No hay suficiente combustible para despegar.");
        }
    }
    public void avanzar(int distancia) {
        int consumo = distancia * 5;
        if (combustible >= consumo) {
            combustible -= consumo;
            System.out.println("La nave avanzp " + distancia + " unidades. Combustible restante: " + combustible);
        } else {
            System.out.println("No hay suficiente combustible para avanzar " + distancia + " unidades.");
        }
    }
    public void recargarCombustible(int cantidad) {
        if (combustible + cantidad > MAX_COMBUSTIBLE) {
            combustible = MAX_COMBUSTIBLE;
            System.out.println("Se recargo al maximo. Combustible actual: " + combustible);
        } else {
            combustible += cantidad;
            System.out.println("Se recargaron " + cantidad + " unidades. Combustible actual: " + combustible);
        }
    }

    public void mostrarEstado() {
        System.out.println("Estado de la nave:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Combustible: " + combustible + "/" + MAX_COMBUSTIBLE);
        System.out.println("---------------------------");
    }
}
