/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio4;

import java.util.ArrayList;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Animal> animales = new ArrayList<>();

        // Creamos y agregamos los objetos al ArrayList
        Perro perro1 = new Perro();
        Gato gato1 = new Gato();
        Vaca vaca1 = new Vaca();

        animales.add(perro1);
        animales.add(gato1);
        animales.add(vaca1);

        // Recorremos la lista y cada animal ejecuta su propio sonido
        for (Animal a : animales) {
            a.hacerSonido();
    }
   }
}
