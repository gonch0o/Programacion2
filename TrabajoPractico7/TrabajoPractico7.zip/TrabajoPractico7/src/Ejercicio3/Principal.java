/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio3;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Empleado[] empleados = {
            new EmpleadoPlanta("Ana", 600000, 80000),
            new EmpleadoTemporal("Luis", 160, 2500)
        };

        for (Empleado e : empleados)
            System.out.println(e.getNombre() + " cobra $" + e.calcularSueldo());
    }
    
}
