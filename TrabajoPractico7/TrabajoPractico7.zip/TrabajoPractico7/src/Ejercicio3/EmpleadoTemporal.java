/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio3;

/**
 *
 * @author gonzalo
 */
public class EmpleadoTemporal extends Empleado{
    private int horasTrabajadas;
    private double valorHora;
    public EmpleadoTemporal(String nombre, int horas, double valor) {
        super(nombre);
        this.horasTrabajadas = horas;
        this.valorHora = valor;
    }
    @Override
    public double calcularSueldo() { return horasTrabajadas * valorHora; }
}
