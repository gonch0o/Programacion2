/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio2;

import java.util.ArrayList;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Figura> figuras = new ArrayList<>();

        Rectangulo r1 = new Rectangulo("Rectángulo A", 5.5, 3.2);
        Rectangulo r2 = new Rectangulo("Rectángulo B", 8.0, 2.5);
        Circulo c1 = new Circulo("Círculo Azul", 4.2);
        Circulo c2 = new Circulo("Círculo Verde", 6.0);

        figuras.add(r1);
        figuras.add(r2);
        figuras.add(c1);
        figuras.add(c2);

        for (Figura f : figuras) {
            f.calcularArea();
    }
   }
}
