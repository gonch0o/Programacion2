/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio12tp2;

/**
 *
 * @author gonzalo
 */
public class Ejercicio12Tp2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double[] precios = {199.99, 299.50, 149.75, 399.00, 89.99};
        
        System.out.println("precios originales:");
        for (double precio : precios) {
            System.out.println("precio: $" + precio);
        }
        
        precios[2] = 129.99;

        System.out.println("\nPrecios modificados:");
        for (double precio : precios) {
            System.out.println("precio: $" + precio);
        }
    }
    
}
