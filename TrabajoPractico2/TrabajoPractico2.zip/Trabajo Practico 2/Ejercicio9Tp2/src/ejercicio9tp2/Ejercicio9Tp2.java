/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio9tp2;

import java.util.Scanner;

/**
 *
 * @author gonzalo
 */
public class Ejercicio9Tp2 {

    public static double calcularCostoEnvio(double peso, String zona) {
        double costoEnvio;
        if (zona.equalsIgnoreCase("nacional")) {
            costoEnvio = peso * 5;
        } else if (zona.equalsIgnoreCase("internacional")) {
            costoEnvio = peso * 10;
        } else {
            System.out.println("zona invalida. Se tomara costo de envio 0.");
            costoEnvio = 0;
        }
        return costoEnvio;
    }    
    public static double calcularTotalCompra(double precioProducto, double costoEnvio) {
        return precioProducto + costoEnvio;
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double precioProducto, peso, costoEnvio, total;
        String zona;      
        
        System.out.print("ingrese el precio del producto: ");
        precioProducto = Double.parseDouble(input.nextLine() );

        System.out.print("ingrese el peso del paquete en kg: ");
        peso = Double.parseDouble(input.nextLine() );

        System.out.print("ingrese la zona de envio (nacional/internacional): ");
        zona = input.nextLine();

        // Cálculos
        costoEnvio = calcularCostoEnvio(peso, zona);
        total = calcularTotalCompra(precioProducto, costoEnvio);

        // Salida
        System.out.println("\nEl costo de envio es: " + costoEnvio);
        System.out.println("el total a pagar es: " + total);
        
    }
    
}
