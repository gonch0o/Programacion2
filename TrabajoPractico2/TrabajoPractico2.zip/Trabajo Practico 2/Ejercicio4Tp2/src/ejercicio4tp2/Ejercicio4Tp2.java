/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio4tp2;

import java.util.Scanner;

/**
 *
 * @author gonzalo
 */
public class Ejercicio4Tp2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double precio, descuento, montoDescuento, precioFinal;
        char categoria;
        
        System.out.print("Ingrese el precio del producto: ");
        precio = Double.parseDouble(input.nextLine() );
        
        System.out.print("Ingrese la categoria del producto (A, B O C): ");
        categoria = input.next().toUpperCase().charAt(0);
        
        descuento = 0;
        
        switch (categoria) {
            case 'A':
                descuento = 0.10;
                break;
            case 'B':
                descuento = 0.15;
                break;
            case 'C':
                descuento = 0.20;
                break;
            default:
                System.out.println("categoria incorrecta");
                return;
        }
        montoDescuento = precio * descuento;
        precioFinal = precio - montoDescuento;
        
        System.out.println("precio original: " + precio);
        System.out.println("descuento aplicado: " + (int)(descuento * 100) + "%");
        System.out.println("precio final: " + precioFinal);
    }
    
}
