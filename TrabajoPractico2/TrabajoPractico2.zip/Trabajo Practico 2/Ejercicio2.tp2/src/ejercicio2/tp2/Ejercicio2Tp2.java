/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2.tp2;

import java.util.Scanner;

/**
 *
 * @author gonzalo
 */
public class Ejercicio2Tp2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1, num2, num3, numMayor;
                
        System.out.print("ingrese el primer numero: ");
        num1 = Integer.parseInt(input.nextLine());
        
        System.out.print("ingrese el segundo numero: ");
        num2 = Integer.parseInt(input.nextLine());
        
        System.out.print("ingrese el tercer numero: ");
        num3 = Integer.parseInt(input.nextLine()); 
      
        if (num1 >= num2 && num1 >= num3){
            numMayor = num1;            
        } else if (num2 >= num1 && num2 >= num3) {
            numMayor = num2;
        } else {
            numMayor = num3;
        }
        System.out.println("el mayor es: " + numMayor);
    }
    
}
