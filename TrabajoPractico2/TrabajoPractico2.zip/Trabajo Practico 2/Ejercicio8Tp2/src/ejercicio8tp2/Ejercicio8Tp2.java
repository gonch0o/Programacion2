/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8tp2;

import java.util.Scanner;

/**
 *
 * @author gonzalo
 */
public class Ejercicio8Tp2 {

    public static double calcularPrecioFinal(double precioBase, double impuesto, double descuento) {
        double precioFinal = precioBase + (precioBase * (impuesto / 100)) - (precioBase * (descuento / 100));
        return precioFinal;
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double precioBase, impuesto, descuento, precioFinal;
        
        System.out.print("ingrese el precio base del producto: ");
        precioBase = Double.parseDouble(input.nextLine() );
        
        System.out.print("ingrese el impuesto: ");
        impuesto = Double.parseDouble(input.nextLine() );
        
        System.out.print(" ingrese el descuento: ");
        descuento = Double.parseDouble(input.nextLine() );
        
        precioFinal = calcularPrecioFinal(precioBase, impuesto, descuento);
        System.out.println("el precio final del producto es: " + precioFinal);
    }
    
}
