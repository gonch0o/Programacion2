/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio5tp2;

import java.util.Scanner;

/**
 *
 * @author gonzalo
 */
public class Ejercicio5Tp2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int numero;
        int suma = 0;
        
        System.out.print("ingrese un numero (0 para terminar): ");
        numero = Integer.parseInt(input.nextLine());
        
        while (numero != 0) {
            if (numero % 2 == 0) {
                suma += numero;                
            }
            
            System.out.print("ingrese un numero (0 para terminar): ");
            numero = Integer.parseInt(input.nextLine());
        }
        
        System.out.println("la suma de los numeros pares es: " + suma);
    }
    
}
