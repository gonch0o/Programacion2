/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio10tp2;

import java.util.Scanner;

/**
 *
 * @author gonzalo
 */
public class Ejercicio10Tp2 {

    public static int actualizarStock(int stockActual, int cantidadVendida, int cantidadRecibida) {
        return stockActual - cantidadVendida + cantidadRecibida;
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int stockActual, cantidadVendida, cantidadRecibida, nuevoStock;

        System.out.print("ingrese el stock actual del producto: ");
        stockActual = Integer.parseInt(input.nextLine());

        System.out.print("ingrese la cantidad vendida: ");
        cantidadVendida = Integer.parseInt(input.nextLine());

        System.out.print("ingrese la cantidad recibida: ");
        cantidadRecibida = Integer.parseInt(input.nextLine());

        nuevoStock = actualizarStock(stockActual, cantidadVendida, cantidadRecibida);

        System.out.println("\nEl nuevo stock del producto es: " + nuevoStock);
    }
    
}
