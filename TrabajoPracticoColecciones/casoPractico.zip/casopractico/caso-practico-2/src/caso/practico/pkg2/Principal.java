/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso.practico.pkg2;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Biblioteca b = new Biblioteca("Biblioteca Central");

       
        Autor a1 = new Autor("A1", "Antonio Santa Ana", "Argentina");
        Autor a2 = new Autor("A2", "Jorge L. Borges", "Argentina");
        Autor a3 = new Autor("A3", "Edgar Allan Poe", "Estados Unido");

        
        b.agregarLibro("ISBN-001", "Los ojos del perro siberiano", 1998, a1);
        b.agregarLibro("ISBN-002", "Ficciones", 1944, a2);
        b.agregarLibro("ISBN-003", "El cuervo", 1845, a3);
        b.agregarLibro("ISBN-004", "El Aleph", 1949, a2);
        b.agregarLibro("ISBN-005", "Nunca sere un superheroe", 2000, a1);

        
        System.out.println("\n-- Listar libros --");
        b.listarLibros();

        
        System.out.println("\n-- Buscar por ISBN (ISBN-004) --");
        Libro encontrado = b.buscarLibroPorIsbn("ISBN-004");
        if (encontrado != null) encontrado.mostrarInfo();

       
        System.out.println("\n-- Libros del año 2000 --");
        for (Libro l : b.filtrarLibrosPorAnio(2000)) l.mostrarInfo();

     
        System.out.println("\n-- Eliminar ISBN-003 y listar --");
        b.eliminarLibro("ISBN-003");
        b.listarLibros();

        System.out.println("\n-- Cantidad total de libros --");
        System.out.println(b.obtenerCantidadLibros());

        System.out.println("\n-- Autores disponibles --");
        b.mostrarAutoresDisponibles();
    }
    
}
