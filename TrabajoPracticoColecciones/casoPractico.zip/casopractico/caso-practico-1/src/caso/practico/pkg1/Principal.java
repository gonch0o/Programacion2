/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso.practico.pkg1;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        inventario.agregarProducto(new Producto("A1", "Arroz", 1500, 20, CategoriaProducto.ALIMENTOS));
        inventario.agregarProducto(new Producto("E1", "Televisor", 250000, 5, CategoriaProducto.ELECTRONICA));
        inventario.agregarProducto(new Producto("R1", "Campera", 18000, 12, CategoriaProducto.ROPA));
        inventario.agregarProducto(new Producto("H1", "Silla", 22000, 7, CategoriaProducto.HOGAR));
        inventario.agregarProducto(new Producto("A2", "Galletitas", 1200, 15, CategoriaProducto.ALIMENTOS));

        System.out.println("Listado de productos:");
        inventario.listarProductos();

        System.out.println("\nBuscar producto por ID (R1):");
        inventario.buscarProductoPorId("R1").mostrarInfo();

        System.out.println("\nProductos en categoría ALIMENTOS:");
        inventario.filtrarPorCategoria(CategoriaProducto.ALIMENTOS);

        System.out.println("\nEliminar producto H1:");
        inventario.eliminarProducto("H1");
        inventario.listarProductos();

        System.out.println("\n Actualizar stock de A1 a 30 unidades:");
        inventario.actualizarStock("A1", 30);
        inventario.buscarProductoPorId("A1").mostrarInfo();

        System.out.println("\nTotal de stock disponible: " + inventario.obtenerTotalStock());

        System.out.println("\nProducto con mayor stock:");
        System.out.println(inventario.obtenerProductoConMayorStock());

        System.out.println("\nProductos entre $1000 y $30000:");
        inventario.filtrarProductosPorPrecio(1000, 30000);

        System.out.println("\nCategorías disponibles:");
        inventario.mostrarCategoriasDisponibles();
    
    }
    
}
