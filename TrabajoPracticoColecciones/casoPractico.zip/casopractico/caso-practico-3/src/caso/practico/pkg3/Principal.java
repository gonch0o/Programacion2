/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso.practico.pkg3;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Universidad u = new Universidad("UTN");

        Profesor p1 = new Profesor("P1","Ana Torres","Matematica");
        Profesor p2 = new Profesor("P2","Luis Gomez","Programacion");
        Profesor p3 = new Profesor("P3","Maria Diaz","Base de Datos");

        Curso c1 = new Curso("ALG-101","Álgebra");
        Curso c2 = new Curso("PRO-101","Programación I");
        Curso c3 = new Curso("PRO-201","Programación II");
        Curso c4 = new Curso("ING-101","Ingles");
        Curso c5 = new Curso("BD-101","Bases de Datos");

        u.agregarProfesor(p1); u.agregarProfesor(p2); u.agregarProfesor(p3); u.agregarCurso(c1); u.agregarCurso(c2); u.agregarCurso(c3); u.agregarCurso(c4); u.agregarCurso(c5);

        u.asignarProfesorACurso("ALG-101","P1");
        u.asignarProfesorACurso("PRO-101","P2");
        u.asignarProfesorACurso("PRO-201","P2");
        u.asignarProfesorACurso("BD-101","P3");

        u.listarCursos();
        u.listarProfesores();

        System.out.println("\nCambio de profesor: PRO-201 -> P3");
        u.asignarProfesorACurso("PRO-201","P3");
        u.listarCursos();
        u.listarProfesores();

        System.out.println("\nEliminar curso PRO-101");
        u.eliminarCurso("PRO-101");
        u.listarProfesores();

        System.out.println("\nEliminar profesor P3");
        u.eliminarProfesor("P3");
        u.listarCursos();

        System.out.println();
        u.reporteCursosPorProfesor();
    }
    
}
