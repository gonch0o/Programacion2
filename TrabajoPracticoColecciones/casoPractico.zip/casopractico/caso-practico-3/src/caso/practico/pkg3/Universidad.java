/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caso.practico.pkg3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gonzalo
 */
public class Universidad {
   private String nombre;
    private List<Profesor> profesores = new ArrayList<>();
    private List<Curso> cursos = new ArrayList<>();

    public Universidad(String nombre) { 
        this.nombre = nombre; 
    }

    public void agregarProfesor(Profesor p) {
        if (p != null && !profesores.contains(p)) profesores.add(p);
    }

    public void agregarCurso(Curso c) {
        if (c != null && !cursos.contains(c)) cursos.add(c);
    }

    public Profesor buscarProfesorPorId(String id) {
        for (Profesor p : profesores) 
            if (p.getId().equals(id)) 
                return p;
        return null;
    }

    public Curso buscarCursoPorCodigo(String codigo) {
        for (Curso c : cursos) 
            if (c.getCodigo().equals(codigo)) 
                return c;
        return null;
    }

    public void asignarProfesorACurso(String codigoCurso, String idProfesor) {
        Curso c = buscarCursoPorCodigo(codigoCurso);
        Profesor p = buscarProfesorPorId(idProfesor);
        if (c == null || p == null) {
            System.out.println("No se pudo asignar");
            return;
        }
        c.setProfesor(p);
    }

    public void listarProfesores() {
        System.out.println("Profesores en " + nombre + ":");
        for (Profesor p : profesores) {
            p.mostrarInfo();
            p.listarCursos();
        }
    }

    public void listarCursos() {
        System.out.println("Cursos en " + nombre + ":");
        for (Curso c : cursos) c.mostrarInfo();
    }

    public void eliminarCurso(String codigo) {
        Curso c = buscarCursoPorCodigo(codigo);
        if (c == null) 
            return;
        c.setProfesor(null);
        cursos.remove(c);
    }

    public void eliminarProfesor(String id) {
        Profesor p = buscarProfesorPorId(id);
        if (p == null) 
            return;
     
        var copia = new ArrayList<>(p.getCursos());
        for (Curso c : copia) c.setProfesor(null);
        profesores.remove(p);
    }

    public void reporteCursosPorProfesor() {
        System.out.println("Reporte: cursos por profesor");
        for (Profesor p : profesores) {
            System.out.println(p.getNombre() + ": " + p.getCursos().size());
        }
    } 
}
