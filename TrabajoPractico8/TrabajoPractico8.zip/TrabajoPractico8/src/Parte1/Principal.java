/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Parte1;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente c = new Cliente("Gonzalo");
        Pedido pedido = new Pedido(c);

        pedido.agregarProducto(new Producto("Harina", 1500));
        pedido.agregarProducto(new Producto("Aceite", 2500));

        double total = pedido.calcularTotal();
        System.out.println("Total del pedido: $" + total);

        PagoConDescuento pago = new TarjetaCredito();
        pago.aplicarDescuento(10);
        pago.procesarPago(total * 0.9);

    }
    
}
