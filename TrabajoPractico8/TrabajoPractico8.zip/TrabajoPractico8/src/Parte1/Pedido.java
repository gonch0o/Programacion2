/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Parte1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gonzalo
 */
public class Pedido implements Pagable, Notificable{
    private List<Producto> productos;
    private Cliente cliente;

    public Pedido(Cliente cliente) {
        this.productos = new ArrayList<>();
        this.cliente = cliente;
    }

    public void agregarProducto(Producto p) {
        productos.add(p);
        notificar("Se agregó el producto: " + p);
    }

    @Override
    public double calcularTotal() {
        double total = 0;
        for (Producto p : productos)
            total += p.calcularTotal();
        return total;
    }

    @Override
    public void notificar(String mensaje) {
        cliente.recibirNotificacion(mensaje);
    }
}
