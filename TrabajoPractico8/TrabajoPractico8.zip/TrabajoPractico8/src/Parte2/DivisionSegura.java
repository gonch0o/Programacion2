/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Parte2;

import java.util.Scanner;

/**
 *
 * @author gonzalo
 */
public class DivisionSegura {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingresá el dividendo (entero): ");
        int a = sc.nextInt();

        System.out.print("Ingresá el divisor (entero): ");
        int b = sc.nextInt();

        dividir(a, b);

        System.out.println("Fin del programa.");
    }
    public static void dividir(int a, int b) {
        try {
            int r = a / b;
            System.out.println("Resultado: " + r);
        } catch (ArithmeticException e) {
            System.out.println("Error: no se puede dividir por cero.");
        }
    }
   }
