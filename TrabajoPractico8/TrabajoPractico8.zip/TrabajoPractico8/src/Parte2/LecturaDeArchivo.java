/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Parte2;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author gonzalo
 */
public class LecturaDeArchivo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        VisorDeTXTs v = new VisorDeTXTs();
        try {
            v.mostrarTxt("src/Parte2/MENSAJE.txt");
        } catch (FileNotFoundException ex){
            System.out.println("El archivo no existe");
        } catch (IOException ex){
            System.out.println("Error de E/S");
            System.out.println(ex.getMessage());
        }
    }
    
}
