/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Parte2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author gonzalo
 */
public class LecturaConTryResources {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String ruta = "src/Parte2/MENSAJE.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException ex) {
            System.out.println("Error manejado con try-with-resources.");
            System.out.println("Mensaje: " + ex.getMessage());
        } finally {
            System.out.println("Bloque finally ejecutado.");
        }
    }
    
}
