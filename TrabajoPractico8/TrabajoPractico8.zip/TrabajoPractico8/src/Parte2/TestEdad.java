/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Parte2;

/**
 *
 * @author gonzalo
 */
public class TestEdad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            EdadInvalida.verificarEdad(-5);   // cambiar el numero para probar
        } catch (EdadInvalidaException ex) {
            System.out.println("Excepción capturada: " + ex.getMessage());
        } finally {
            System.out.println("Bloque finally ejecutado.");
        }
    }
    
}
