/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Parte2;

import java.util.Scanner;

/**
 *
 * @author gonzalo
 */
public class ConversionCadena {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingresá un número entero: ");
        String texto = sc.nextLine();

        try {
            int numero = Integer.parseInt(texto);
            System.out.println("Número convertido correctamente: " + numero);
        } catch (NumberFormatException e) {
            System.out.println("Error: la cadena ingresada no es un número válido.");
        }

        System.out.println("Fin del programa.");
        }
    }
    

