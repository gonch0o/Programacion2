/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajopractico4;

/**
 *
 * @author gonzalo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Empleado e1 = new Empleado(101, "Ana lopez", "Gerente", 120000);
        Empleado e2 = new Empleado("Carlos Perez", "Analista");
        
        e1.actualizarSalario(10);
        e2.actualizarSalario(5000);
        
        System.out.println(e1.toString());
        System.out.println(e2.toString());
        
        System.out.println("Total de empleados: " + Empleado.mostrarTotalEmpleados());

    }
    
}
